Esercizio local storage
salvataggio in locale
quando si riapre la pagina si vedono gli items inseriti in precedenza